# Roteiro — Apresentação ao Diretor (BIA Tech DevOps / cockpit · curadoria · chat)

**Objetivo:** patrocínio para escalar · **Duração:** ~15 min (demo pesada) · **Ângulo:** inovação / posicionamento
**Fecho:** termina num *ask* (piloto reversível de 30 dias).

> Legenda: **[FALA]** = o que dizer · **[AÇÃO]** = o que fazer na tela/slide · **[PREENCHER]** = dado seu a completar antes.
> Regras aplicadas: tese primeiro / provas depois · 1 ideia por bloco · pausa dá autoridade · nunca terminar em "então, é isso".

---

## Antes de entrar (checklist de 2 min)
- Respiração lenta para baixar a ativação; "pose de poder" 2 min. Nervosismo é biologia, não fraqueza.
- **Memorize conceitos, não frases** (evita o branco). Deu branco? Pare, respire, retome do último ponto.
- Prepare o terreno: idealmente esta **não** é a primeira vez que o diretor ouve a ideia. Se houver pares dele na sala, você já falou com eles antes.
- Deixe **cockpit, curadoria e chat já abertos** em abas, com um caso real carregado. Plano B: um GIF/vídeo gravado da demo, caso a rede falhe.
- Perguntas difíceis: tenha 1 dado curto para cada (custo, prazo, risco, segurança). "Opinião é fraca, dado é forte."

---

## 0:00–1:30 · Abertura — GANCHO A (prova física) + por que agora
**Slide:** Capa

**[FALA — gancho, os 3 primeiros segundos decidem]**
> "Olha essa tela. É um **chamado real** que entrou hoje de manhã. *(pausa)* Agora olha o **Pull Request** que saiu dele — sem ninguém tocar no teclado. *(pausa)* E o mais importante hoje **não é a IA**: é o que a gente colocou **na frente** dela."

**[FALA — contexto que justifica o gancho + por que agora]**
> "Todo mês, o time de TI gasta horas repetindo o mesmo diagnóstico para os mesmos erros. Isso é custo invisível e é lentidão na entrega. Nós construímos a **BIA Tech DevOps**: ela pega o chamado, diagnostica e devolve a correção — e reaproveita o que já foi resolvido, em vez de refazer. Já está rodando em piloto. Em 15 minutos eu mostro o caso ao vivo e o que preciso de você para **escalar**."

**[AÇÃO]** Avançar. Não faça bio longa — no máximo uma frase de quem você é, se necessário.

---

## 1:30–3:00 · Arquitetura ao vivo
**Slides:** "BIA Tech DevOps em uma frase" → **Arquitetura** (o mapa dos serviços)

**[FALA — tese primeiro, uma frase]**
> "A BIA Tech DevOps é uma solução **agêntica de remediação**: erro entra no cockpit, ela busca na base de soluções e devolve uma correção confiável."

**[AÇÃO]** Ir para o slide da Arquitetura. Apontar o fluxo da esquerda para a direita.

**[FALA — a leitura do mapa, sem jargão]**
> "O **cockpit** é a porta de entrada — o operador cola o run. A partir daí o erro ganha uma **assinatura única** (fingerprint). Antes de pensar, o sistema **consulta a memória**: se esse erro já foi resolvido, a resposta vem do **cache** na hora. Se é novo, o **RAG** procura na base de conhecimento. Só o que é **realmente novo** vai para a **curadoria**, onde o agente **AgentiX** propõe a correção — e um humano aprova. O PR é montado com **dupla trava** e aberto via git-ops."

**[FALA — a deixa para o próximo slide]**
> "Repara numa coisa: a **IA fica no fim**, não no começo. E isso não foi escolha estética — é o padrão que o mercado adotou."

---

## 3:00–3:50 · Slide de referência — posicionamento (NOVO)
**Slide:** "Não é gambiarra. É padrão de indústria." *(inserido logo após a arquitetura)*

**[FALA — o argumento de posicionamento, ~45s]**
> "Reaproveitar processamento em vez de refazer a cada chamada é **padrão consolidado** de quem faz IA a sério. A **Anthropic** faz isso no nível do prompt — o *prompt caching* reaproveita o contexto para cortar custo e latência. A **AWS** leva ao nível da resposta: um **cache semântico** que serve casos equivalentes **sem chamar o modelo**, derrubando a latência de segundos para milissegundos. *(pausa)* O que a AWS e a Anthropic **recomendam**, a BIA Tech DevOps **já faz**: cache e RAG na frente, a IA só no que é novo. Não estamos seguindo a moda — estamos no padrão certo, e na frente."

**[AÇÃO]** Não leia as citações em voz alta; elas estão no slide como prova. Aponte e siga.

**Referências (fontes das citações do slide):**
- Anthropic — *Prompt Caching* (Claude Platform Docs): https://platform.claude.com/docs/en/build-with-claude/prompt-caching
- AWS — *Persistent semantic cache in Amazon MemoryDB* (AWS Database Blog, 16/08/2024): https://aws.amazon.com/blogs/database/improve-speed-and-reduce-cost-for-generative-ai-workloads-with-a-persistent-semantic-cache-in-amazon-memorydb

---

## 3:50–11:30 · HANDS-ON (o núcleo — demo pesada)
**Slides:** "Demo ao vivo" → (proposta) "Conheça a BIA Tech DevOps" / "O chat" → "Hands-on"

> Regra: **cada demo embrulhada numa micro-história** (um chamado real), não em recurso técnico. Storytelling > informação pura.

### (a) Cockpit — ~2:30
**[FALA — micro-história]**
> "Esse é o chamado que entrou hoje. *(cola o run)* Olha o que o cockpit faz: importa, gera a assinatura e já dispara o diagnóstico."

**[AÇÃO]** Colar o run · mostrar o diagnóstico aparecendo · destacar o **caso com match** (resposta instantânea do cache = **zero chamada de IA**).

**[FALA — ancorar no ganho]**
> "Esse aqui já era conhecido — resposta na hora, **sem gastar IA**. É o cache trabalhando."

### (b) Curadoria — ~2:30
**[FALA — micro-história]**
> "Agora um erro que o sistema **não** conhecia. Ele não inventa: manda para a **fila de curadoria**."

**[AÇÃO]** Abrir a fila · mostrar o agente AgentiX propondo a correção · **a aprovação humana** (o gate) · o item virando solução na base.

**[FALA — ancorar em governança/confiança]**
> "Repara: a IA **propõe**, o humano **aprova**. Nada vai para produção sem um dono. E, uma vez aprovado, o **próximo erro igual já cai no cache** — a base aprende sozinha."

### (c) Chat (BIA Tech DevOps) — ~2:30
**[FALA — micro-história]**
> "E para o dia a dia do desenvolvedor, não precisa nem abrir chamado: ele pergunta pra **BIA Tech DevOps**."

**[AÇÃO]** Abrir o chat · fazer uma pergunta real · mostrar a resposta com a solução/*link do PR* quando houver.

**[FALA — a ponte para o fecho]**
> "Mesma inteligência, três portas: cockpit para o chamado, curadoria para o conhecimento, chat para a dúvida. *(pausa)* Isso é o que já existe. Agora, o tamanho da oportunidade."

---

## 11:30–13:00 · Prova (Big Numbers)
**Slide:** "Big Numbers"

**[FALA — dado embrulhado em história, prova ANTES do pedido]**
> "No piloto, pegamos [PREENCHER: nº de chamados / período]. Desses, **[PREENCHER: %]** foram resolvidos **sem acionar a IA** — direto do cache. O tempo médio de um chamado desses caiu de **[PREENCHER]** para **[PREENCHER]**. *(pausa)* Cada erro repetido que a BIA Tech DevOps absorve é uma hora que o time não gasta duas vezes."

> Se não tiver número fechado: use o dado mais forte que tiver e seja honesto sobre o recorte. Um dado real e modesto vale mais que um número redondo inventado.

---

## 13:00–14:15 · O PEDIDO (ask de patrocínio)
**Slide:** "Fecho"

**[FALA — Contexto → Prova → Recomendação → Ask → convite]**
> "Então: o custo do diagnóstico manual repetido é real *(contexto)*; já validamos que dá para automatizar boa parte dele *(prova)*. Minha recomendação é **escalar a BIA Tech DevOps para [PREENCHER: N times / esteiras]** no próximo trimestre. Para isso eu preciso de **[PREENCHER: aval / verba / infra]**. E proponho começar **reversível**: um **piloto de 30 dias** nesses times, antes de mudar qualquer fluxo definitivo."

**[FALA — frase de eco + pergunta que força posicionamento]**
> "A pergunta que eu deixo é simples: **queremos ser a área que lidera essa mudança — ou a que corre atrás dela?**"

**[AÇÃO]** Se fizer sentido, se posicione como responsável pela execução: "e eu topo tocar isso." Quem define o próximo passo lidera a sala.

---

## 14:15–15:00 · Q&A curto + fecho
**Slide:** "Obrigado"

- **Deixe as perguntas ANTES do encerramento**, nunca depois do "obrigado". Respostas curtas e diretas.
- Se travar numa pergunta: "ótima pergunta — te trago o número exato depois", e siga. Não improvise dado.
- **Nunca** termine com "então, é isso". Termine repetindo a frase de eco e o próximo passo:
> "Escala reversível, 30 dias, e a gente lidera. Obrigado."

---

## Perguntas difíceis prováveis (tenha 1 resposta curta cada)
- **"E o custo da IA?"** → "A arquitetura foi feita pra gastar IA só no que é novo — cache e RAG na frente. É o padrão AWS/Anthropic." 
- **"E segurança / risco?"** → "Nada entra em produção sem aprovação humana; o PR tem dupla trava e há kill-switch."
- **"Por que agora e não depois?"** → "Cada trimestre manual é custo que não volta, e a vantagem é de quem automatiza primeiro."
- **"Isso não é reinventar o que já existe no mercado?"** → "Ao contrário: é o padrão de mercado, adaptado ao nosso CI/CD e à nossa base — roda dentro de casa, com nosso dado."

---

## Pós-reunião (não pule — aqui se ganha ou perde visibilidade)
- Envie um **e-mail de resumo** no mesmo dia: decisão, próximos passos, responsáveis e prazo. **Quem envia o resumo assume a liderança invisível da reunião.**

---

### Notas de entrega
- **Pausa** é sua arma nº 1 de autoridade numa fala curta — use depois de cada frase de impacto (marcadas com *(pausa)*).
- Corte 30% do que ensaiar: clareza retém, volume cansa. 15 min é 15 min.
- Voz: module volume e ritmo; postura ereta; se for remoto, câmera na altura dos olhos e olhar na lente.
